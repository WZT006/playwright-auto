import{aA as a,aB as r,aC as s,n}from"./DGjthc3V.js";const c=a(async()=>{let e,t;if(!([e,t]=r(()=>s()),e=await e,t(),e))return n("/")});export{c as default};

import{u as e}from"./CqQ3SWju.js";import{aC as r}from"./DGjthc3V.js";const m=s=>r(e().name);export{m as g};

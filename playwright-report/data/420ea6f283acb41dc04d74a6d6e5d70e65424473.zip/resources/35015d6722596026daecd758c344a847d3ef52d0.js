const t=window.setInterval;export{t as s};

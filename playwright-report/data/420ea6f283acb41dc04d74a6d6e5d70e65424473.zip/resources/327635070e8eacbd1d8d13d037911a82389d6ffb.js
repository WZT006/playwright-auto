import{G as o}from"./DGjthc3V.js";function c(){const{$sentryVue:r}=o(),t=r();return{captureError:(e,n)=>{t.captureException(e,{extra:{context:n}})}}}export{c as u};

import{G as p}from"./DGjthc3V.js";const s=()=>p().$firebaseApp;export{s as u};

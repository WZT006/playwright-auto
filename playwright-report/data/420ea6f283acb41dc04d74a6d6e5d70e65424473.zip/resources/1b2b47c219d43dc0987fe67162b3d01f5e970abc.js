import{G as s}from"./DGjthc3V.js";function r(e=s()){var t;return(t=e.ssrContext)==null?void 0:t.event}function a(e){return{}}function o(e,t,u){}export{r as a,o as s,a as u};
